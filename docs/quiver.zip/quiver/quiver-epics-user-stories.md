# Quiver — Épicas e Historias de Usuario (MVP)

> Basado en `quiver-mvp-definition.md`. Las referencias entre corchetes (ej: `[DA-01]`) apuntan a las decisiones de arquitectura y decisiones pendientes del documento de definición.

---

## Índice de épicas

| ID | Épica | Historias |
|---|---|---|
| E1 | Setup e inicialización | 5 |
| E2 | Autenticación | 6 |
| E3 | Roles y permisos | 4 |
| E4 | Gestión de usuarios | 5 |
| E5 | CRUD Engine | 11 |
| E6 | Dashboard | 3 |
| E7 | Layouts y navegación | 6 |
| E8 | Páginas custom | 3 |
| E9 | Portal | 4 |
| E10 | Control de acceso en frontend | 5 |
| | **Total** | **52** |

---

## Personas

- **Developer** — el programador que instala y configura Quiver en su proyecto.
- **Admin** — usuario con rol `admin` que usa el panel de administración.
- **Cliente** — usuario con rol de portal (`cliente`, `cliente_premium`, etc.) que usa el portal.
- **Superuser** — admin con `is_superuser=true` que bypasea todos los permisos.

---

---

## E1 — Setup e inicialización

> El developer puede clonar el starter kit, configurarlo y tener el sistema funcionando en local en el menor tiempo posible.

---

### E1-US1 — Arranque del proyecto desde cero

**Como** developer,
**quiero** clonar el repositorio de Quiver, instalar dependencias y arrancar el servidor con un mínimo de pasos,
**para** poder empezar a desarrollar sin invertir tiempo en configuración de infraestructura.

**Criterios de aceptación:**
- El repositorio incluye un `README.md` con los pasos exactos para arrancar el proyecto por primera vez.
- Con no más de 5 comandos el developer tiene el backend y el frontend corriendo en local.
- El backend arranca en el puerto configurado y sirve Swagger en `/docs`.
- El frontend arranca con Vite y el proxy hacia el backend está configurado automáticamente.
- Si falta alguna variable de entorno obligatoria, el servidor no arranca y muestra un mensaje claro indicando qué falta.

**Notas técnicas:**
- `[DA-01]` El proyecto se clona, no se instala vía pip.
- `[DA-02]` El router de Quiver se monta dentro del FastAPI del proyecto con `app.include_router(quiver.router)`.
- Variables de entorno mínimas requeridas: `SECRET_KEY`, `DATABASE_URL`, `QUIVER_ENV`.

---

### E1-US2 — Creación del superuser inicial

**Como** developer,
**quiero** crear el primer usuario superuser mediante un comando de gestión,
**para** tener acceso al panel de admin desde el primer día sin depender de la UI.

**Criterios de aceptación:**
- Existe un comando CLI (ej: `python manage.py create-superuser`) que solicita email y contraseña.
- El comando valida que el email no existe previamente.
- El usuario creado tiene `is_superuser=true` e `is_active=true`.
- Si ya existe un superuser, el comando muestra un aviso y pide confirmación antes de crear otro.
- El comando está documentado como paso obligatorio en el README de setup.

**Notas técnicas:**
- `[DP-05]` El superuser nunca se crea desde la UI.
- `[DA-03]` El superuser vive en la tabla `admin_users`.

---

### E1-US3 — Configuración del EmailSender

**Como** developer,
**quiero** poder conectar mi proveedor de email (SendGrid, SES, SMTP, etc.) implementando una interfaz simple,
**para** que el sistema de reset de contraseña funcione con el servicio que use mi proyecto.

**Criterios de aceptación:**
- Existe una clase abstracta `EmailSender` con un único método `send_reset_email(to, token)`.
- El developer crea su implementación y la registra en la configuración de Quiver.
- Si no hay `EmailSender` configurado, el endpoint `POST /auth/forgot-password` responde `503` con el mensaje `"EmailSender not configured. See documentation."`.
- La documentación incluye un ejemplo de implementación para SMTP estándar.

**Notas técnicas:**
- `[DP-04]` La interfaz abstracta desacopla Quiver de cualquier proveedor concreto.

---

### E1-US4 — Configuración de roles del portal

**Como** developer,
**quiero** declarar en la configuración del proyecto qué roles tienen acceso al portal,
**para** que el sistema de acceso funcione correctamente sin modificar el código del router.

**Criterios de aceptación:**
- Existe la variable de configuración `QUIVER_PORTAL_ROLES` que acepta una lista de strings.
- El rol `"admin"` se añade automáticamente a la lista efectiva, aunque no se declare.
- El valor de `QUIVER_PORTAL_ROLES` se expone en el endpoint `GET /portal/pages` para que el frontend pueda construir sus guardas de ruta.
- Si `QUIVER_PORTAL_ROLES` está vacío o no configurado, el portal requiere únicamente estar autenticado.

**Notas técnicas:**
- `[Laguna A — sistema de roles]` Evita tener los roles hardcodeados en `router.tsx`.

---

### E1-US5 — Registro de CRUDs en QuiverApp

**Como** developer,
**quiero** registrar mis clases `QuiverCRUD` de forma explícita en la instancia de `QuiverApp`,
**para** que el engine genere los endpoints y valide la configuración al arrancar.

**Criterios de aceptación:**
- La API es `quiver.register(MiCRUD)`.
- Al arrancar, Quiver valida que el `route` de cada CRUD no colisione con slugs reservados.
- Si hay colisión, el servidor no arranca y muestra un mensaje claro: `"ProductCRUD: route 'config' is reserved by Quiver."`.
- Si un `SelectField` referencia un CRUD no registrado, el servidor no arranca con mensaje: `"SelectField 'category_id' references 'categories' but no QuiverCRUD is registered for that route."`.
- Los CRUDs registrados aparecen en los logs de arranque.

**Notas técnicas:**
- `[DA-05]` Registro explícito, sin autodescubrimiento.
- `[DP-06]` Lista de slugs reservados: `config`, `menu`, `dashboard`, `pages`, `users`, `roles`, `permissions`, `choices`, `auth`, `portal`.

---

---

## E2 — Autenticación

> Cualquier usuario puede iniciar y cerrar sesión de forma segura. Las sesiones persisten y se renuevan de forma transparente.

---

### E2-US1 — Login con email y contraseña

**Como** usuario (admin o cliente),
**quiero** iniciar sesión con mi email y contraseña,
**para** acceder a la zona del sistema que me corresponde.

**Criterios de aceptación:**
- El formulario de login valida que los campos no estén vacíos antes de enviar.
- Si las credenciales son incorrectas, se muestra el mensaje `"Email o contraseña incorrectos"` sin especificar cuál de los dos falla.
- Si el usuario tiene `is_active=false`, el mensaje es `"Tu cuenta está desactivada. Contacta con el administrador."`.
- Tras login exitoso, el usuario es redirigido a `/admin` si tiene rol `admin`, o a `/portal` si solo tiene roles de portal.
- El access token se guarda en memoria (Zustand), nunca en `localStorage`.
- El refresh token llega en una cookie `HttpOnly`, `SameSite=Strict`.

**Notas técnicas:**
- `[Flujo 1 — Login]` Flujo completo documentado en la sección 5 de la definición.
- La redirección post-login usa el campo `redirect_to` de la respuesta del backend.

---

### E2-US2 — Persistencia de sesión al recargar

**Como** usuario,
**quiero** que al recargar la página no tenga que volver a hacer login,
**para** tener una experiencia fluida sin interrupciones.

**Criterios de aceptación:**
- Al montar el SPA, si hay cookie de refresh válida, se renueva el access token automáticamente.
- El usuario no ve la pantalla de login si su sesión está activa.
- Durante la hidratación se muestra un estado de carga (spinner o skeleton) para evitar flashes de contenido no autenticado.
- Si el refresh token está expirado o revocado, el usuario es redirigido a `/auth/login`.

**Notas técnicas:**
- `[Flujo 2 — Hidratación]` El access token vive en memoria; la cookie persiste entre recargas.

---

### E2-US3 — Refresco silencioso del token

**Como** usuario,
**quiero** poder seguir usando el sistema aunque mi token expire,
**para** no perder mi trabajo o ser interrumpido de forma inesperada.

**Criterios de aceptación:**
- Cuando una request recibe un 401, el interceptor de Axios intenta renovar el token automáticamente.
- Si el refresco tiene éxito, la request original se reintenta de forma transparente.
- El usuario no recibe ningún aviso ni ve ningún cambio en la UI.
- Si el refresco falla (token revocado o expirado), el usuario es redirigido a `/auth/login`.
- No pueden producirse condiciones de carrera: si hay varias requests simultáneas con el token expirado, solo se hace una llamada a `/auth/refresh`.

**Notas técnicas:**
- `[Flujo 3 — Refresco silencioso]` El interceptor vive en `src/api/client.ts`.

---

### E2-US4 — Cierre de sesión

**Como** usuario,
**quiero** cerrar sesión de forma segura,
**para** proteger mi cuenta cuando termine de usar el sistema.

**Criterios de aceptación:**
- Existe un botón de logout visible en el `AdminLayout` y en el `UserLayout`.
- Al hacer logout, el refresh token queda revocado en base de datos.
- La cookie de refresh token queda vaciada en el navegador.
- El access token del store queda limpio.
- El usuario es redirigido a `/auth/login`.
- Si hay un error de red al hacer logout, el store y la cookie se limpian igualmente en el cliente (logout local garantizado).

**Notas técnicas:**
- `[Flujo 4 — Logout]` `POST /auth/logout` + `revoked_at` en `refresh_tokens`.

---

### E2-US5 — Solicitud de reset de contraseña

**Como** usuario que olvidó su contraseña,
**quiero** solicitar un enlace de recuperación a mi email,
**para** recuperar el acceso a mi cuenta sin necesitar ayuda del administrador.

**Criterios de aceptación:**
- El formulario de `ForgotPasswordPage` acepta un email y muestra confirmación al enviar.
- La respuesta es siempre `200 OK`, independientemente de si el email existe o no en el sistema.
- El mensaje de confirmación es neutro: `"Si el email existe, recibirás un enlace en breve."`.
- El enlace del email tiene una validez de 1 hora.
- Si el `EmailSender` no está configurado, el endpoint devuelve `503` y la UI muestra un mensaje de error.

**Notas técnicas:**
- `[DP-04]` El comportamiento 200-siempre previene la enumeración de usuarios.

---

### E2-US6 — Cambio de contraseña con token de reset

**Como** usuario con un enlace de reset válido,
**quiero** establecer una nueva contraseña,
**para** recuperar el acceso a mi cuenta.

**Criterios de aceptación:**
- El formulario pide la nueva contraseña y su confirmación.
- Si las contraseñas no coinciden, se muestra un error antes de enviar.
- Si el token es inválido o ha expirado, se muestra un mensaje claro con un link para solicitar uno nuevo.
- Si el token ya fue usado, se muestra un mensaje indicándolo.
- Tras el reset exitoso, todas las sesiones del usuario quedan revocadas en todos los dispositivos.
- El usuario es redirigido a `/auth/login` con un mensaje de éxito.

**Notas técnicas:**
- `[DP-03]` La revocación de todas las sesiones es intencional y debe comunicarse al usuario en el mensaje de éxito.

---

---

## E3 — Roles y permisos

> El sistema permite definir y gestionar qué puede hacer cada usuario en el sistema, tanto en el área admin como en el portal.

---

### E3-US1 — Definición de permisos en código

**Como** developer,
**quiero** declarar los permisos de mi aplicación en código Python usando la convención `resource.action`,
**para** tener un sistema de permisos consistente y que se sincronice automáticamente con la base de datos.

**Criterios de aceptación:**
- Existe una función o decorador para registrar permisos: `quiver_permission("products.list", group="Productos", display_name="Listar productos")`.
- Los permisos se sincronizan con la tabla `permissions` en el arranque de la aplicación (upsert).
- Los permisos eliminados del código no se borran automáticamente de la BD (previene pérdida de datos accidental).
- La convención de nombre `resource.action` se valida al registrar: nombre en minúsculas, sin espacios, con exactamente un punto.
- Los permisos generados automáticamente por el CRUD engine siguen la misma convención.

**Notas técnicas:**
- `[Sección 6 — Roles y permisos]` Los permisos son de solo lectura en la UI.

---

### E3-US2 — Gestión de roles desde la UI

**Como** admin con permiso `roles.list`,
**quiero** ver, crear, editar y eliminar roles,
**para** organizar los niveles de acceso del sistema.

**Criterios de aceptación:**
- La pantalla de roles muestra la lista de roles con su `display_name`, número de permisos y número de usuarios asignados.
- Se puede crear un rol indicando `name` (slug) y `display_name`.
- El `name` se valida como slug único (minúsculas, sin espacios ni caracteres especiales).
- Se puede editar el `display_name` y la `description`. El `name` (slug) no es editable una vez creado.
- Al intentar eliminar un rol que tiene usuarios asignados, se muestra un aviso con el número de usuarios afectados y se pide confirmación.
- No se puede eliminar el último rol con acceso al área admin si dejaría al sistema sin admins.

**Notas técnicas:**
- `[Sección 8 — Gestión de roles]` Endpoints `POST/PUT/DELETE /admin/roles`.

---

### E3-US3 — Asignación de permisos a roles

**Como** admin con permiso `roles.update`,
**quiero** asignar y quitar permisos a un rol mediante una interfaz visual,
**para** configurar el acceso granular de cada rol a los módulos del sistema.

**Criterios de aceptación:**
- Al editar un rol, se muestra una matriz de checkboxes con los permisos agrupados por `group`.
- Los grupos están ordenados alfabéticamente. Los permisos dentro de cada grupo también.
- Guardar envía el array completo de permisos seleccionados (operación replace-all).
- Hay un botón "Seleccionar todos" y "Deseleccionar todos" por grupo para agilizar la configuración.
- Tras guardar, se muestra una confirmación de éxito.
- Los cambios de permisos tienen latencia de hasta 15 minutos para los usuarios ya logueados (documentado en un tooltip o nota informativa en la UI).

**Notas técnicas:**
- `[DP-01]` La latencia de 15 minutos es inherente al uso de JWT con payload de permisos.

---

### E3-US4 — Asignación de roles a usuarios

**Como** admin con permiso `users.update`,
**quiero** asignar y quitar roles a un usuario,
**para** controlar a qué zonas y recursos tiene acceso.

**Criterios de aceptación:**
- En la pantalla de edición de usuario se muestra un selector múltiple con todos los roles disponibles.
- Los roles asignados actualmente aparecen preseleccionados.
- Se puede asignar o quitar cualquier combinación de roles.
- El campo `assigned_at` se actualiza al modificar los roles.
- Un admin no puede quitarse a sí mismo el rol `admin` (previene autobloqueo).

**Notas técnicas:**
- `[Sección 4 — ERD]` Pivot `user_has_roles` con `assigned_at`.

---

---

## E4 — Gestión de usuarios

> El administrador puede gestionar el ciclo de vida completo de los usuarios del sistema desde el panel de admin.

---

### E4-US1 — Listado de usuarios

**Como** admin con permiso `users.list`,
**quiero** ver la lista de todos los usuarios con información relevante,
**para** tener visibilidad completa de quién tiene acceso al sistema.

**Criterios de aceptación:**
- La tabla muestra: email, nombre completo, roles asignados (como badges), estado activo/inactivo, y fecha de último login.
- Los usuarios inactivos aparecen visualmente diferenciados (ej: fila en gris o badge "Inactivo").
- La columna `last_login_at` muestra "Nunca" si el usuario nunca ha hecho login.
- Se puede buscar por email o nombre.
- Se puede filtrar por estado (activo / inactivo) y por rol.
- La tabla está ordenada por `created_at` DESC por defecto.

**Notas técnicas:**
- `[Sección 8 — Gestión de usuarios]` `GET /admin/users`.

---

### E4-US2 — Creación de usuario

**Como** admin con permiso `users.create`,
**quiero** crear un nuevo usuario asignándole roles en el mismo formulario,
**para** incorporar personas al sistema de forma eficiente.

**Criterios de aceptación:**
- El formulario incluye: email, nombre, apellidos, contraseña, confirmar contraseña, roles (selector múltiple), estado activo.
- El email se valida como único en el sistema antes de enviar.
- La contraseña tiene un mínimo de 8 caracteres.
- Si la contraseña y la confirmación no coinciden, se muestra el error antes de enviar.
- El usuario recibe un email de bienvenida si el `EmailSender` está configurado (post-MVP, pero el campo se reserva).
- Tras la creación, se redirige a la pantalla de detalle del usuario recién creado.

---

### E4-US3 — Edición de usuario

**Como** admin con permiso `users.update`,
**quiero** editar los datos y roles de un usuario existente,
**para** mantener la información actualizada.

**Criterios de aceptación:**
- Se pueden editar: nombre, apellidos, email, estado activo, y roles.
- La contraseña solo se cambia si el admin introduce un valor en el campo "Nueva contraseña" (si se deja vacío, no se modifica).
- Un admin no puede editar su propio email (previene autobloqueo).
- Un admin no puede desactivarse a sí mismo.
- Los cambios se guardan con confirmación visual de éxito.

**Notas técnicas:**
- `[Sección 8 — Gestión de usuarios]` `PUT /admin/users/{id}`.

---

### E4-US4 — Desactivación de usuario

**Como** admin con permiso `users.delete`,
**quiero** desactivar un usuario,
**para** revocar su acceso sin borrar sus datos del sistema.

**Criterios de aceptación:**
- La acción de desactivar pide confirmación con el nombre del usuario.
- Al desactivar, el campo `is_active` pasa a `false`. No se borra el registro.
- Todos los refresh tokens del usuario desactivado quedan revocados automáticamente.
- El usuario desactivado recibe un 401 en su próxima request y es redirigido al login.
- El admin no puede desactivarse a sí mismo.
- En la tabla de usuarios, el usuario aparece con estado "Inactivo".

**Notas técnicas:**
- `[DP-02]` Soft disable, no hard delete. Preserva integridad referencial.

---

### E4-US5 — Detalle de usuario

**Como** admin con permiso `users.show`,
**quiero** ver el detalle completo de un usuario,
**para** revisar su configuración sin entrar en modo edición.

**Criterios de aceptación:**
- La vista muestra todos los campos del usuario en modo lectura.
- Se muestran los roles asignados con sus `display_name`.
- Se muestra la fecha de `last_login_at` formateada (o "Nunca").
- Se muestran los botones "Editar" y "Desactivar" según los permisos del admin logueado.

---

---

## E5 — CRUD Engine

> El developer puede generar un módulo completo de administración para cualquier modelo SQLModel declarando una clase con mínima configuración.

---

### E5-US1 — Declaración básica de un CRUD

**Como** developer,
**quiero** extender `QuiverCRUD` con solo `model` y `route` para obtener endpoints CRUD funcionales,
**para** poner en marcha la administración de un recurso en minutos.

**Criterios de aceptación:**
- Con solo `model` y `route` definidos, el engine genera los 7 endpoints: `GET /config`, `GET /`, `POST /`, `GET /{id}`, `PUT /{id}`, `DELETE /{id}`, `DELETE /` (bulk).
- Los permisos se auto-generan como `{route}.list`, `.create`, `.show`, `.update`, `.delete`.
- Las columnas y fields se auto-generan desde el modelo SQLModel. Los campos `id`, `created_at` y `updated_at` se excluyen de los fields del formulario por defecto.
- Los endpoints están protegidos por los permisos correspondientes.
- El CRUD aparece en el menú admin si el developer lo ha añadido a la configuración de menú.

**Notas técnicas:**
- `[Sección 9 — CRUD Engine]` Tres modos de columnas/fields: explícito, exclude, o auto-total.

---

### E5-US2 — Configuración de columnas del listado

**Como** developer,
**quiero** controlar qué columnas aparecen en la tabla del listado,
**para** mostrar solo la información relevante para el administrador.

**Criterios de aceptación:**
- Se puede declarar `columns = [Column(...), ...]` para definir exactamente las columnas.
- Se puede declarar `exclude_columns = ["campo1", "campo2"]` para mostrar todas menos las excluidas.
- Si no se declara ninguno, se muestran todas las columnas del modelo.
- Cada columna acepta: `key`, `label`, `col_type`, `sortable`.
- La columna de acciones (edit / delete) se añade siempre automáticamente al final.
- Los tipos de columna disponibles son: `text`, `number`, `currency`, `badge`, `date`, `datetime`, `boolean`, `link`.

---

### E5-US3 — Configuración de fields del formulario

**Como** developer,
**quiero** controlar qué campos aparecen en los formularios de creación y edición,
**para** exponer solo los campos editables por el administrador.

**Criterios de aceptación:**
- Se puede declarar `fields = [TextField(...), ...]` para definir exactamente los campos.
- Se puede declarar `exclude_fields = ["slug"]` para incluir todos menos los excluidos.
- Si no se declara ninguno, se incluyen todos los campos del modelo excepto `id`, `created_at` y `updated_at`.
- Los tipos de campo disponibles son: `text`, `email`, `password`, `number`, `textarea`, `select`, `select_multiple`, `checkbox`, `date`, `datetime`, `hidden`.
- El campo `password` nunca se devuelve en los `GET`.
- Cada field acepta: `label`, `required`, `help_text`, `read_only`, `default`.

---

### E5-US4 — Filtros en el listado

**Como** developer,
**quiero** configurar filtros en el CRUD,
**para** que el administrador pueda acotar los registros que necesita ver.

**Criterios de aceptación:**
- Se puede declarar `filters = [TextFilter(...), SelectFilter(...), ...]`.
- Los filtros se renderizan en un panel colapsable sobre la tabla.
- Los filtros activos quedan visualmente marcados.
- Al limpiar un filtro se recarga la tabla.
- Los tipos de filtro disponibles son: `TextFilter` (ILIKE), `SelectFilter` (exact match), `BooleanFilter` (sí/no/todos), `DateRangeFilter` (desde/hasta).
- Los filtros se envían como query params al endpoint `GET /admin/{resource}`.

---

### E5-US5 — Búsqueda global y ordenación

**Como** admin,
**quiero** buscar registros por texto y ordenar la tabla por columna,
**para** encontrar y explorar los datos de forma eficiente.

**Criterios de aceptación:**
- Existe un campo de búsqueda global sobre la tabla que filtra por los `search_fields` configurados en el CRUD.
- La búsqueda aplica ILIKE sobre todos los `search_fields` simultáneamente (OR).
- Hacer clic en la cabecera de una columna `sortable=true` ordena la tabla por ese campo.
- Un segundo clic invierte el orden (ASC → DESC → sin orden).
- La columna ordenada actualmente muestra un indicador visual de dirección.
- La búsqueda y el orden se combinan con los filtros activos.

---

### E5-US6 — Bulk delete

**Como** admin con permiso `{resource}.delete`,
**quiero** seleccionar múltiples registros y borrarlos en una sola acción,
**para** gestionar datos de forma eficiente.

**Criterios de aceptación:**
- Hay un checkbox en la primera columna de cada fila y uno en la cabecera para seleccionar/deseleccionar todos.
- Al seleccionar al menos un registro, aparece una barra de acciones bulk con el conteo de seleccionados.
- La acción "Eliminar seleccionados" pide confirmación con el número de registros afectados.
- El endpoint `DELETE /admin/{resource}` recibe los IDs y devuelve cuántos se borraron.
- Los registros que no existían se ignoran sin error.
- Tras el borrado, la tabla se recarga y la selección se limpia.

---

### E5-US7 — Hooks de ciclo de vida en el CRUD

**Como** developer,
**quiero** sobreescribir métodos `before_create`, `after_create`, etc. en mi clase CRUD,
**para** añadir lógica de negocio sin abandonar el engine.

**Criterios de aceptación:**
- Los hooks disponibles son: `before_create`, `after_create`, `before_update`, `after_update`, `before_delete`, `after_delete`.
- `before_create` y `before_update` reciben `data` (dict), `db` y `user`, y deben devolver `data` (modificado o no).
- `after_create` y `after_update` reciben la instancia guardada, `db` y `user`.
- `before_delete` y `after_delete` reciben la instancia (o su ID tras borrar), `db` y `user`.
- Si un hook lanza una excepción, la operación se cancela y se hace rollback.
- Si el developer necesita reemplazar completamente la lógica, puede sobreescribir el método `create`, `update` o `delete` directamente.

---

### E5-US8 — get_queryset para filtrar el listado base

**Como** developer,
**quiero** sobreescribir `get_queryset` en mi CRUD,
**para** filtrar los registros que ve el admin según su contexto (tenancy, permisos propios, etc.).

**Criterios de aceptación:**
- `get_queryset(db, user)` devuelve la query SQLModel base sobre la que se aplican paginación, búsqueda y filtros.
- Por defecto devuelve todos los registros del modelo sin filtros adicionales.
- El mismo `get_queryset` se usa cuando este CRUD es la fuente de un `SelectField` en otro CRUD (choices).
- Está documentado con un ejemplo de uso para filtrado por `owner_id`.

---

### E5-US9 — SelectField con choices dinámicos

**Como** developer,
**quiero** usar `SelectField(choices_from="categories")` para que el formulario cargue las opciones desde otro CRUD,
**para** crear relaciones FK en los formularios sin trabajo manual.

**Criterios de aceptación:**
- `choices_from="categories"` genera automáticamente el endpoint `GET /admin/categories/choices`.
- El endpoint devuelve `[{value, label}]` usando `value_field` y `label_field` configurables (por defecto `id` y `name`).
- El endpoint requiere el permiso `categories.list`.
- Si el CRUD `categories` no está registrado, el arranque falla con mensaje claro.
- El endpoint respeta el `get_queryset` del CRUD referenciado.
- El frontend carga los choices al abrir el formulario (lazy load).

---

### E5-US10 — Vista de detalle (Show) de un registro

**Como** admin,
**quiero** ver el detalle de un registro en modo lectura,
**para** revisar su información sin riesgo de modificarla accidentalmente.

**Criterios de aceptación:**
- La URL `/admin/{resource}/{id}` renderiza la `ShowPage`.
- Se muestran todos los fields configurados en modo lectura.
- Los campos de tipo `password` no se muestran nunca.
- Hay botones "Editar" y "Eliminar" visibles según los permisos del usuario.
- Si el registro no existe, se muestra un mensaje 404 claro con un botón para volver al listado.

---

### E5-US11 — Paginación del listado

**Como** admin,
**quiero** navegar por páginas en los listados de recursos con muchos registros,
**para** que la tabla sea usable con grandes volúmenes de datos.

**Criterios de aceptación:**
- La paginación muestra: primera página, última página, página actual, páginas adyacentes y botones anterior/siguiente.
- El `page_size` por defecto es el configurado en el CRUD (default: 25). El usuario puede cambiarlo.
- El total de registros se muestra ("1-25 de 1.432 registros").
- Al cambiar de página se mantienen los filtros y el orden activos.
- La URL refleja la página actual para que sea navegable con el botón atrás del navegador.

---

---

## E6 — Dashboard

> El admin dispone de una pantalla de inicio con métricas y datos relevantes del negocio configurados por el developer.

---

### E6-US1 — Pantalla de dashboard

**Como** admin,
**quiero** ver una pantalla de inicio con widgets de información al entrar al panel,
**para** tener una visión rápida del estado del sistema sin navegar por los módulos.

**Criterios de aceptación:**
- La ruta `/admin` renderiza el `DashboardPage`.
- El dashboard llama a `GET /admin/dashboard` y renderiza los widgets devueltos.
- Solo se muestran los widgets para los que el usuario tiene permiso.
- Si no hay widgets configurados, se muestra un mensaje informativo para el developer.
- El layout del dashboard es un grid responsive: 1 columna en móvil, 2-3 en escritorio.

---

### E6-US2 — Widget de contador (StatCard)

**Como** developer,
**quiero** configurar tarjetas con contadores de registros en el dashboard,
**para** que el admin vea las métricas más importantes de un vistazo.

**Criterios de aceptación:**
- `StatCardWidget(title="Usuarios", model=AdminUser, permission="users.list")` genera una tarjeta con el total de registros del modelo.
- La tarjeta muestra: título, número grande y un icono opcional.
- Se puede configurar un filtro adicional (ej: contar solo usuarios activos).
- Si el usuario no tiene el permiso configurado, el widget no aparece en la respuesta de `GET /admin/dashboard`.

---

### E6-US3 — Widget de gráfico (ChartWidget)

**Como** developer,
**quiero** configurar widgets de gráfico de línea o barras en el dashboard,
**para** visualizar tendencias de datos con series temporales o por categorías.

**Criterios de aceptación:**
- `ChartWidget` acepta una query Python que devuelve `[{label, value}]` o `[{label, series1, series2}]`.
- El developer configura el tipo (`line` o `bar`), el título y los colores.
- El frontend usa Recharts para renderizar el gráfico.
- El gráfico es responsive y se adapta al ancho del grid.

---

---

## E7 — Layouts y navegación

> El sistema proporciona layouts listos para usar y un menú lateral dinámico. El developer puede personalizar el portal libremente.

---

### E7-US1 — AdminLayout listo para usar

**Como** developer,
**quiero** que el panel de admin tenga un layout profesional (sidebar + topbar) sin que tenga que construirlo,
**para** empezar a desarrollar funcionalidades de negocio desde el primer día.

**Criterios de aceptación:**
- El `AdminLayout` incluye: sidebar colapsable, topbar con nombre de usuario y botón de logout, área de contenido principal, y breadcrumbs.
- El sidebar muestra el logo/nombre de la app (configurable en `QuiverConfig`).
- El layout es responsive: en móvil el sidebar se colapsa y hay un botón de hamburguesa.
- El `AdminLayout` está marcado como "no modificar" en los comentarios del código y la documentación.

---

### E7-US2 — Menú lateral dinámico

**Como** developer,
**quiero** configurar la estructura del menú lateral del admin desde Python,
**para** organizar la navegación según los módulos de mi proyecto.

**Criterios de aceptación:**
- La configuración `QUIVER_MENU` acepta grupos e items: `MenuGroup(title, items=[MenuItem(label, route, permission)])`.
- El menú se carga al hacer login mediante `GET /admin/menu`.
- El item activo (ruta actual) aparece resaltado visualmente.
- Los grupos son colapsables y recuerdan su estado abierto/cerrado.

---

### E7-US3 — Filtrado del menú por permisos

**Como** admin,
**quiero** que el menú solo muestre los módulos a los que tengo acceso,
**para** no ver opciones que no puedo utilizar.

**Criterios de aceptación:**
- El backend filtra los items del menú según los permisos del usuario antes de devolver la respuesta.
- Un item sin el permiso requerido no aparece en la respuesta — no aparece deshabilitado, directamente no aparece.
- Si todos los items de un grupo quedan filtrados, el grupo tampoco aparece.
- El menú se actualiza al recargar la sesión (refleja cambios de permisos tras el tiempo de latencia).

**Notas técnicas:**
- `[DP-01]` Los cambios de permisos tienen latencia de hasta 15 minutos.

---

### E7-US4 — UserLayout personalizable

**Como** developer,
**quiero** un punto de partida para el layout del portal que pueda modificar libremente,
**para** que el portal tenga la identidad visual y la estructura que necesita mi proyecto.

**Criterios de aceptación:**
- `UserLayout.tsx` existe en el starter kit con una estructura mínima funcional (navbar, área de contenido, footer).
- El fichero incluye comentarios claros indicando qué partes modificar.
- El layout tiene un `<Outlet />` de React Router donde se renderizan las páginas del portal.
- El `UserLayout` usa los mismos tokens de diseño (colores, tipografía) que el admin, pero puede sobreescribirlos.

---

### E7-US5 — Navegación del admin al portal

**Como** admin,
**quiero** poder acceder al portal desde el panel de admin,
**para** no quedarme atrapado en la zona de admin y poder revisar la experiencia del usuario.

**Criterios de aceptación:**
- El `AdminLayout` incluye un link/botón "Ver portal" en la topbar o en el sidebar.
- El link solo es visible si el usuario tiene acceso al portal (está en algún rol de `QUIVER_PORTAL_ROLES`).
- El link navega a `/portal`.

---

### E7-US6 — Navegación del portal al admin

**Como** usuario con rol admin que está en el portal,
**quiero** ver un acceso directo de vuelta al panel de administración,
**para** cambiar de zona rápidamente sin tener que editar la URL.

**Criterios de aceptación:**
- El `UserLayout` muestra un link/badge "Panel de admin" visible únicamente para usuarios con rol `"admin"`.
- El link navega a `/admin`.
- Para usuarios sin rol `admin` este elemento no existe en el DOM (no solo oculto con CSS).

---

---

## E8 — Páginas custom

> El developer puede registrar páginas propias tanto en el área admin como en el portal, que se integran con el sistema de auth, permisos, menú y layout de Quiver.

---

### E8-US1 — Páginas custom en el área admin

**Como** developer,
**quiero** registrar páginas React personalizadas en el área admin usando `@quiver_page`,
**para** añadir vistas específicas del negocio (reportes, herramientas, etc.) dentro del panel.

**Criterios de aceptación:**
- `@quiver_page(route="/admin/reportes", layout="admin", permission="reports.view", title="Reportes", component="ReportsPage")` registra la página.
- La página aparece en la respuesta de `GET /admin/pages`.
- El frontend crea dinámicamente la ruta `/admin/reportes` envuelta en `RequireRole(["admin"])` y protegida por el permiso `reports.view` via `Can`.
- La página se renderiza dentro del `AdminLayout` con su sidebar y topbar.
- El breadcrumb muestra el `title` configurado.
- El componente React `ReportsPage` debe existir en el frontend e importarse en `router.tsx`.

---

### E8-US2 — Páginas custom en el portal

**Como** developer,
**quiero** registrar páginas React personalizadas en el portal usando `@quiver_page` con `allowed_roles`,
**para** construir la experiencia del usuario final con el sistema de acceso de Quiver.

**Criterios de aceptación:**
- `@quiver_page(route="/portal/vip", layout="portal", allowed_roles=["cliente_premium", "admin"], title="Zona VIP", component="VipPage")` registra la página.
- La página aparece en la respuesta de `GET /portal/pages` solo si el usuario tiene alguno de los `allowed_roles`.
- El frontend crea dinámicamente la ruta `/portal/vip` envuelta en `RequireRole(["cliente_premium", "admin"])`.
- La página se renderiza dentro del `UserLayout`.
- Si el usuario no tiene el rol requerido y accede directamente a la URL, ve la `ForbiddenPage`.

---

### E8-US3 — Uso de Can y HasRole en páginas custom

**Como** developer,
**quiero** usar `<Can>` y `<HasRole>` dentro de mis páginas custom,
**para** mostrar u ocultar secciones según el acceso del usuario sin lógica adicional.

**Criterios de aceptación:**
- `<Can>` y `<HasRole>` están disponibles para importar desde el paquete core de Quiver.
- Funcionan igual en páginas custom del admin que del portal.
- El comportamiento con `is_superuser=true` es consistente: siempre muestra los hijos.
- La documentación incluye ejemplos de uso en ambos contextos.

---

---

## E9 — Portal

> El portal de usuario es la zona de cara al cliente. Quiver proporciona la estructura base y la welcome page; el developer construye el contenido.

---

### E9-US1 — Portal welcome page en development

**Como** developer recién instalado,
**quiero** ver una página informativa al acceder a `/portal`,
**para** confirmar que el portal está funcionando y saber cómo empezar a personalizarlo.

**Criterios de aceptación:**
- Con `QUIVER_ENV=development`, la ruta `/portal` muestra una página con: confirmación de que el portal funciona, nombre y roles del usuario logueado, instrucciones para personalizar el portal, y enlace a la documentación.
- La página deja claro que es un placeholder y cómo reemplazarla.
- El endpoint `GET /portal/` devuelve `{message, version, user: {name, roles[]}}`.

---

### E9-US2 — Portal welcome page en producción

**Como** cliente que accede al portal antes de que esté construido,
**quiero** ver un mensaje genérico de bienvenida,
**para** no ver contenido técnico o de desarrollo.

**Criterios de aceptación:**
- Con `QUIVER_ENV=production`, la ruta `/portal` muestra únicamente un mensaje de bienvenida genérico sin información técnica.
- El mensaje es configurable en `QuiverConfig` (ej: `portal_welcome_message`).
- El mensaje por defecto es neutral: "Bienvenido. Esta sección está disponible próximamente."

---

### E9-US3 — Ver perfil propio en el portal

**Como** cliente,
**quiero** ver mis datos de perfil en el portal,
**para** saber con qué cuenta estoy logueado y revisar mi información.

**Criterios de aceptación:**
- La ruta `/portal/perfil` muestra: nombre, apellidos, email y roles del usuario.
- Los datos se cargan de `GET /portal/me`.
- El email y los roles son de solo lectura.
- Hay un botón "Editar perfil" visible si el usuario tiene acceso a la edición.

---

### E9-US4 — Editar perfil propio en el portal

**Como** cliente,
**quiero** actualizar mi nombre y contraseña desde el portal,
**para** mantener mi información al día sin depender del administrador.

**Criterios de aceptación:**
- El formulario de edición permite cambiar nombre, apellidos y contraseña.
- La contraseña solo se actualiza si el usuario introduce un valor (campo opcional).
- Si cambia la contraseña, debe confirmarla en un segundo campo.
- El usuario no puede cambiar su propio email ni su rol.
- Tras guardar se muestra confirmación de éxito.

---

---

## E10 — Control de acceso en frontend

> El frontend protege las rutas y la visibilidad de los componentes de forma consistente con el sistema de permisos y roles del backend.

---

### E10-US1 — Protección de rutas por rol

**Como** developer,
**quiero** usar `RequireRole` para proteger rutas completas del SPA según el rol del usuario,
**para** que un usuario sin el rol adecuado no pueda acceder a una zona aunque conozca la URL.

**Criterios de aceptación:**
- `<RequireRole roles={["admin"]} />` redirige a `/auth/login` si el usuario no está autenticado.
- Si está autenticado pero no tiene ninguno de los roles requeridos, redirige a `/403`.
- El componente es compatible con el patrón de rutas anidadas de React Router 6.
- `RequireRole` siempre permite el paso si el usuario tiene `is_superuser=true`.
- La comprobación usa los roles del store (JWT), no hace llamadas a la API.

---

### E10-US2 — Visibilidad de elementos por permiso (`<Can>`)

**Como** developer,
**quiero** usar `<Can do="permiso">` para mostrar u ocultar elementos de UI según el permiso del usuario,
**para** que la interfaz refleje exactamente lo que cada usuario puede hacer.

**Criterios de aceptación:**
- `<Can do="products.create">...</Can>` renderiza sus hijos solo si el usuario tiene ese permiso.
- Acepta un prop `fallback` que se renderiza si el usuario no tiene el permiso.
- Si no se provee `fallback`, no se renderiza nada (sin elementos vacíos en el DOM).
- Si `is_superuser=true`, siempre renderiza los hijos.
- La comprobación es sincrónica (usa el store en memoria, sin llamadas a la API).

---

### E10-US3 — Visibilidad de elementos por rol (`<HasRole>`)

**Como** developer,
**quiero** usar `<HasRole roles={[...]}>` para mostrar u ocultar elementos según el rol del usuario,
**para** diferenciar la experiencia entre distintos tipos de usuario sin lógica manual.

**Criterios de aceptación:**
- `<HasRole roles={["cliente_premium", "admin"]}>...</HasRole>` renderiza sus hijos si el usuario tiene alguno de los roles del array.
- Acepta un prop `fallback` con el mismo comportamiento que `Can`.
- Si `is_superuser=true`, siempre renderiza los hijos.
- Se puede usar en cualquier zona del SPA (admin, portal, shared components).

---

### E10-US4 — Hooks de permisos y roles

**Como** developer,
**quiero** usar `usePermission()` y `useRole()` para lógica condicional en mis componentes,
**para** controlar el comportamiento (no solo la visibilidad) según el acceso del usuario.

**Criterios de aceptación:**
- `usePermission()` devuelve `{ can(perm: string): boolean, canAny(perms: string[]): boolean }`.
- `useRole()` devuelve `{ hasRole(role: string): boolean, hasAnyRole(roles: string[]): boolean }`.
- Ambos hooks devuelven `true` en todas sus funciones si `is_superuser=true`.
- Son importables desde el paquete core: `import { usePermission, useRole } from "@quiver/core"`.
- La documentación incluye ejemplos de uso para condicionales, clases CSS dinámicas y lógica de negocio.

---

### E10-US5 — Página de acceso denegado (403)

**Como** usuario que intenta acceder a una zona sin permiso,
**quiero** ver una página clara que me explique qué ocurrió,
**para** no quedarme confuso ante una pantalla en blanco o un error genérico.

**Criterios de aceptación:**
- La ruta `/403` renderiza la `ForbiddenPage` built-in.
- La página muestra un mensaje claro: "No tienes permiso para acceder a esta página."
- Hay un botón que lleva al usuario a su página de inicio (`/admin` o `/portal` según su rol).
- El developer puede sobreescribir el componente `ForbiddenPage` si necesita un diseño propio.
- La página no incluye información técnica sobre el permiso requerido (no expone datos de seguridad).

---

---

## Resumen de historias por épica

| Épica | Historias | Developer | Admin | Cliente | Superuser |
|---|---|---|---|---|---|
| E1 — Setup | 5 | 5 | — | — | — |
| E2 — Autenticación | 6 | — | 3 | 3 | — |
| E3 — Roles y permisos | 4 | 1 | 3 | — | — |
| E4 — Gestión de usuarios | 5 | — | 5 | — | — |
| E5 — CRUD Engine | 11 | 7 | 4 | — | — |
| E6 — Dashboard | 3 | 2 | 1 | — | — |
| E7 — Layouts y navegación | 6 | 4 | 1 | 1 | — |
| E8 — Páginas custom | 3 | 3 | — | — | — |
| E9 — Portal | 4 | 1 | — | 3 | — |
| E10 — Control de acceso | 5 | 3 | — | — | — |
| **Total** | **52** | **26** | **17** | **7** | **—** |

---

*Documento generado a partir de `quiver-mvp-definition.md`. Versión 1.0.*
